document.addEventListener("DOMContentLoaded", function(event) {
  @@include('./blocks/animationHeight.js');
});